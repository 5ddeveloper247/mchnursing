<?php return [
'All' => 'All',
'Courses' => 'Courses'
];