<?php

namespace Modules\CourseSetting\Entities;

use Illuminate\Database\Eloquent\Model;

class SchoolSubject extends Model
{
    protected $fillable = [];
}
