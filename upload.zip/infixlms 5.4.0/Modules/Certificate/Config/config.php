<?php

return [
    'name' => 'Certificate'
];
